const Discord = require("discord.js");
const db = require("quick.db");
module.exports.run = async (bot, message, args) => {
  let prefix = (await db.fetch(`prefix_${message.guild.id}`)) || "!";
  let sa = (await db.fetch(`dil_${message.guild.id}`)) || "EN_us";
  if (sa == "TR_tr") {
    if (!message.member.hasPermission("KICK_MEMBERS")) {
      const embed = new Discord.RichEmbed()
        .setDescription(`Ne yazık ki bu komutu kullanmaya yetkin yok.`)
        .setColor("YELLOW");

      message.channel.send(embed);
      return;
    }
    let tag = await db.fetch(`otorolmsj_${message.guild.id}`);
    if (!tag) {
      const embed = new Discord.RichEmbed()
        .setDescription(
          `Eksik bir şey var! otorol ismi zaten ayarlanmamış!\n--------------------------------------------------------`
        )
        .addField(
          "Ek `otorol` komutları!",
          `${prefix}otorol <#Kanal> <Tag>\n${prefix}otorol-sıfırla\n${prefix}otorol-isim <İsim Düzeni>\n${prefix}otorol-isim-sıfırla`
        )
        .addField(
          `otorol-isim komutu değişkenleri;`,
          `-uye- = Üye ismini yazar.\n-tag- = Tagı yazar.\n-sunucu- = Sunucu adını yazar.\n-uyetag- = Üyenin tam adını yazar.`
        )
        .setColor("YELLOW");
      message.channel.send(embed);
      return;
    }

    const embed = new Discord.RichEmbed()
      .setColor("YELLOW")
      .setDescription(`otorol ismi başarıyla sıfırlandı!`);
    message.channel.send(embed);

    db.delete(`otorolmsj_${message.guild.id}`);
  } else {
    let tag = await db.fetch(`otorol_${message.guild.id}`);
    if (!message.member.hasPermission("KICK_MEMBERS")) {
      const embed = new Discord.RichEmbed()
        .setDescription(
          `Unfortunately, you are not authorized to use this command.`
        )
        .setColor("YELLOW");

      message.channel.send(embed);
      return;
    }
    if (!tag) {
      const embed = new Discord.RichEmbed()
        .setDescription(
          `There is something missing! Auto tag name is not already set!\n--------------------------------------------------------`
        )
        .addField(
          "Additional `AUTOTAG` commands!",
          `${prefix}autotag <#Channel> <Tag>\n${prefix}autotag-reset\n${prefix}autotag-name <Name Order>\n${prefix}autotag-name-reset`
        )
        .addField(
          `autotag-name command variables;`,
          `-member- = Write the member name.\n-tag- = Writes tag.\n-server- = Write server name.\n-membertag- = Write the full name of the member.`
        )
        .setColor("YELLOW");
      message.channel.send(embed);
      return;
    }
    const embed = new Discord.RichEmbed()
      .setColor("YELLOW")
      .setDescription(`Auto tag name has been successfully reset!`);
    message.channel.send(embed);

    db.delete(`otorolmsj_${message.guild.id}`);
  }
};

module.exports.conf = {
  aliases: ["autotag-name-reset"],
  permLevel: 3,
  enabled: true,
  guildOnly: true,
  kategori: "moderasyon"
};

module.exports.help = {
  name: "otorol-isim-sıfırla",
  description: "SS",
  usage: "otorol-isim-sıfırla"
};
