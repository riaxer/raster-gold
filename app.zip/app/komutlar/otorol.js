const Discord = require("discord.js"),
  db = require("quick.db");
exports.run = async (client, message, args) => {
  let kontrol = await db.fetch(`dil_${message.guild.id}`);
  let prefix = (await db.fetch(`prefix_${message.guild.id}`)) || "!";
  if (kontrol == "TR_tr") {
    if (!message.member.hasPermission("KICK_MEMBERS")) {
      const embed = new Discord.RichEmbed()
        .setDescription(`Ne yazık ki bu komutu kullanmaya yetkin yok.`)
        .setColor("YELLOW");

      message.channel.send(embed);
      return;
    }

    let tag = args[1];
    let kanal = message.mentions.channels.first();
    if (!kanal) {
      const embed = new Discord.RichEmbed()
        .setDescription(
          `Eksik bir şey var! Bir log kanalı belirtmelisin!\nÖrnek; ${prefix}otorol <#Kanal> <Tag>\n--------------------------------------------------------`
        )
        .addField(
          "Ek `otorol` komutları!",
          `${prefix}otorol <#Kanal> <Tag>\n${prefix}otorol-sıfırla\n${prefix}otorol-isim <İsim Düzeni>\n${prefix}otorol-isim-sıfırla`
        )
        .addField(
          `otorol-isim komutu değişkenleri;`,
          `-uye- = Üye ismini yazar.\n-tag- = Tagı yazar.\n-sunucu- = Sunucu adını yazar.\n-uyetag- = Üyenin tam adını yazar.`
        )
        .setColor("YELLOW");
      message.channel.send(embed);
      return;
    }
    if (!tag) {
      const embed = new Discord.RichEmbed()
        .setDescription(
          `Eksik bir şey var! Bir tag belirtmelisin!\nÖrnek; ${prefix}otorol <#Kanal> <Tag>\n--------------------------------------------------------`
        )
        .addField(
          "Ek `otorol` komutları!",
          `${prefix}otorol <#Kanal> <Tag>\n${prefix}otorol-sıfırla\n${prefix}otorol-isim <İsim Düzeni>\n${prefix}otorol-isim-sıfırla`
        )
        .addField(
          `otorol-isim komutu değişkenleri;`,
          `-uye- = Üye ismini yazar.\n-tag- = Tagı yazar.\n-sunucu- = Sunucu adını yazar.\n-uyetag- = Üyenin tam adını yazar.`
        )
        .setColor("YELLOW");
      message.channel.send(embed);
      return;
    }

    const embed = new Discord.RichEmbed()
      .setColor("YELLOW")
      .setDescription(
        `otorol log kanalı; ${kanal}\nTagı; ${tag} olarak ayarlandı!`
      );
    message.channel.send(embed);

    db.set(`otorolk_${message.guild.id}`, kanal.id);
    db.set(`otorol_${message.guild.id}`, tag);
  } else {
    if (!message.member.hasPermission("KICK_MEMBERS")) {
      const embed = new Discord.RichEmbed()
        .setDescription(`Unfortunately, you are not authorized to use this command.`)
        .setColor("YELLOW");

      message.channel.send(embed);
      return;
    }

    let tag = args[1];
    let kanal = message.mentions.channels.first();
    if (!kanal) {
      const embed = new Discord.RichEmbed()
        .setDescription(
          `There is something missing! You must specify a log channel!\nExample; ${prefix}autotag <#Channel> <Tag>\n--------------------------------------------------------`
        )
        .addField(
          "Additional `AUTOTAG` commands!",
          `${prefix}autotag <#Channel> <Tag>\n${prefix}autotag-reset\n${prefix}autotag-name <Name Order>\n${prefix}autotag-name-reset`
        )
        .addField(
          `autotag-name command variables;`,
          `-member- = Write the member name.\n-tag- = Writes tag.\n-server- = Write server name.\n-membertag- = Write the full name of the member.`
        )
        .setColor("YELLOW");
      message.channel.send(embed);
      return;
    }
    if (!tag) {
      const embed = new Discord.RichEmbed()
        .setDescription(
          `There is something missing! You must specify a tag!\nExample; ${prefix}autotag <#Channel> <Tag>\n--------------------------------------------------------`
        )
        .addField(
          "Additional `AUTOTAG` commands!",
          `${prefix}autotag <#Channel> <Tag>\n${prefix}autotag-reset\n${prefix}autotag-name <Name Order>\n${prefix}autotag-name-reset`
        )
        .addField(
          `autotag-name command variables;`,
          `-member- = Write the member name.\n-tag- = Writes tag.\n-server- = Write server name.\n-membertag- = Write the full name of the member.`
        )
        .setColor("YELLOW");
      message.channel.send(embed);
      return;
    }

    const embed = new Discord.RichEmbed()
      .setColor("YELLOW")
      .setDescription(
        `Autotag log channel; ${kanal}\nTag; set to ${tag}!`
      );
    message.channel.send(embed);

    db.set(`otorolk_${message.guild.id}`, kanal.id);
    db.set(`otorol_${message.guild.id}`, tag);
  }
};
exports.conf = {
  aliases: ["autotag"],
  permLevel: 3,
  enabled: true,
  guildOnly: true
};
exports.help = {
  name: "otorol",
  description: "otorol",
  usage: "otorol"
};
