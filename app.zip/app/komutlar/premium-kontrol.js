const Discord = require('discord.js')
const db = require('quick.db')

exports.run = async (client, message, args) => {
let plasmic = await db.fetch(`premod_${message.guild.id}`)
if (!plasmic) return message.channel.send("Bu sunucuda **premium mod aktif değil**, bu sebepten dolayı premium sunucu kodlarını kullanamazsınız.")
    let pre = await db.fetch(`premod_${message.guild.id}`) 
  let preYazi;
  if (pre == null) preYazi = ' Bu sunucuda premium mod aktif değil.'
  if (pre == 'aktif') preYazi = ' Bu sunucu için premium mod aktif.'
  if (pre == 'deaktif') preYazi = 'Bu sunucuda premium mod aktif değil.'
  const plasmiccode = new Discord.MessageEmbed()
  .setTitle('Premium Kontrol')
  .setColor("RANDOM")
  .setDescription(preYazi)
  message.channel.send(plasmiccode)
  }

exports.conf = {
    enabled: true,
    guildOnly: true,
    aliases: [],
    permLevel: 0,
}

exports.help = {
    name: 'premium-kontrol',
    description: 'Premium Kontrol Eder.',
    usage: 'premium-kontrol'
}  //Plasmic Code・xKqntyZ_