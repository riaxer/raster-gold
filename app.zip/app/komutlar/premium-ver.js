const ayarlar = require('../ayarlar.json');
const Discord = require('discord.js')
const fs = require('fs');
const db = require('quick.db');

exports.run = async (client, message, args) => { 
let plasmic = await db.fetch(`premod_${message.guild.id}`)
if (!plasmic) return message.channel.send("Bu sunucuda **premium mod aktif değil**, bu sebepten dolayı premium sunucu kodlarını kullanamazsınız.")
if(message.author.id !== ayarlar.sahip) return message.channel.send(" Bu komutu sadece sahibim kullanabilir.");
 const args0 = args[0];
  if(!args0) {
    message.channel.send(message.author.username + ", lütfen bir sunucu **ID**'si yaz!")
  } else {
db.set(`premod_${args0}`, "aktif")
  message.channel.send(" Başarıyla premium aktif edildi.")
}
  }
    
exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ['premium-ver'],
    permLevel: 4,
}
exports.help = {
    name: 'premiumver',
    description: 'premium verirsiniz.',
    usage: 'premiumver',
}  //Plasmic Code・xKqntyZ_  